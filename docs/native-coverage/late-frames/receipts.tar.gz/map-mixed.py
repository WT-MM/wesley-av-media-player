from pathlib import Path
import json,subprocess,hashlib,bisect
p=Path('/private/tmp/wam-phase2e/rustdesk-audio-celt/0-opus.mkv'); size=p.stat().st_size; nodes=[];clusters=[]
def vint(f,identifier=False):
 b=f.read(1)
 if not b: raise ValueError('EOF')
 n=next((i for i in range(1,9) if b[0] & (1<<(8-i))),0)
 if not n:raise ValueError('invalid VINT')
 data=b+f.read(n-1)
 if len(data)!=n:raise ValueError('truncated VINT')
 v=int.from_bytes(data,'big'); value=v if identifier else v & ((1<<(7*n))-1)
 return value,n,not identifier and value==(1<<(7*n))-1
with p.open('rb') as f:
 def walk(start,end,segment=False):
  pos=start
  while pos<end:
   f.seek(pos); ident,a,_=vint(f,True); length,b,unknown=vint(f); payload=pos+a+b; stop=end if unknown else payload+length
   if stop>end or stop<=pos:raise ValueError('invalid element span')
   if unknown and ident!=0x18538067:raise ValueError('unsupported unknown-size child')
   nodes.append(dict(offset=pos,id=hex(ident),size=None if unknown else length,end=stop))
   if ident==0x18538067:walk(payload,stop,True)
   elif segment and ident==0x1f43b675:clusters.append(pos)
   pos=stop
  assert pos==end
 walk(0,size)
r=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_packets','-show_entries','packet=pts,duration,pos','-of','json',str(p)],text=True))
packets=sorted(r['packets'],key=lambda x:int(x['pts']));last=None
for i,x in enumerate(packets,1):
 c=bisect.bisect_right(clusters,int(x['pos']))-1
 x.update(ordinal=i,cluster=c,cluster_boundary=last is not None and c!=last);last=c
out=dict(asset=str(p),sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),nodes=nodes,clusters=clusters,packets=packets)
Path('/private/tmp/wam-late-scratch/mixed-packet-map.json').write_text(json.dumps(out,indent=2)); print(len(packets),'packets',len(clusters),'clusters',sum(x['cluster_boundary'] for x in packets),'crossings')
