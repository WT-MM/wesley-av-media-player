from pathlib import Path
import json,subprocess,shlex,hashlib
repo=Path('/private/tmp/wam-late');build=repo/'build';scratch=Path('/private/tmp/wam-late-scratch');commands=json.loads((build/'compile_commands.json').read_text());rows=[]
for suffix,target in [('native_video_consumer.mm','wam_native_video_consumer_test.dir'),('native_playback_metrics.cpp','wam.dir'),('native_video_presenter.mm','wam_native_video_consumer_test.dir')]:
 entry=next(x for x in commands if x['file'].endswith('/'+suffix) and target in x['command'])
 cmd=shlex.split(entry['command']);cmd.remove('-DWAM_NATIVE_BENCHMARK_TELEMETRY=1')
 for flag in ['-MT','-MF','-o']:
  if flag in cmd:i=cmd.index(flag);del cmd[i:i+2]
 if '-MD' in cmd:cmd.remove('-MD')
 out=scratch/(suffix+'.release-off.o');cmd += ['-o',str(out)]
 result=subprocess.run(cmd,cwd=build,capture_output=True,text=True);assert result.returncode==0,result.stderr
 symbols=subprocess.check_output(['nm',str(out)],text=True)
 trace=[s for s in symbols.splitlines() if 'late_trace' in s or 'traceFrame' in s]
 rows.append(dict(source=entry['file'],object_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),trace_symbols=trace,command=cmd))
 assert not trace,trace
(scratch/'compile-out.json').write_text(json.dumps(rows,indent=2));print('No trace symbols in all three Release/OFF translation units')
