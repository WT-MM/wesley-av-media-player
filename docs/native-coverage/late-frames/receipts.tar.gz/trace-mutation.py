from pathlib import Path
import json, subprocess, shlex, os
repo=Path('/private/tmp/wam-late'); build=repo/'build'; scratch=Path('/private/tmp/wam-late-scratch')
source=repo/'src/platform/macos/native_video_consumer.mm'
entry=next(x for x in json.loads((build/'compile_commands.json').read_text()) if x['file'].endswith('/native_video_consumer.mm') and 'wam_native_video_consumer_test.dir' in x['command'])
cmd=shlex.split(entry['command'])
mutant=scratch/'native_video_consumer_mutant.mm'
mutant.write_text(source.read_text().replace('      traceFrame(true);','      static_cast<void>(0);',1))
for flag in ['-MT','-MF','-o']:
 if flag in cmd:
  index=cmd.index(flag); del cmd[index:index+2]
if '-MD' in cmd: cmd.remove('-MD')
cmd[cmd.index(entry['file'])]=str(mutant)
cmd += ['-I'+str(source.parent),'-o',str(scratch/'trace-mutant.o')]
subprocess.run(cmd,cwd=build,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
link=shlex.split((build/'CMakeFiles/wam_native_video_consumer_test.dir/link.txt').read_text())
link[link.index('-o')+1]=str(scratch/'trace-mutant')
index=next(i for i,v in enumerate(link) if v.endswith('/native_video_consumer.mm.o'))
link[index]=str(scratch/'trace-mutant.o')
subprocess.run(link,cwd=build,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
rows=[]; env=os.environ.copy();env['WAM_NATIVE_BENCHMARK_TELEMETRY']='1'
for label,binary in [('fixed',build/'wam_native_video_consumer_test'),('emission-removed',scratch/'trace-mutant'),('restored',build/'wam_native_video_consumer_test')]:
 r=subprocess.run([str(binary)],env=env,capture_output=True,text=True)
 if r.returncode==-9:r=subprocess.run([str(binary)],env=env,capture_output=True,text=True)
 rows.append(dict(phase=label,rc=r.returncode,stdout=r.stdout,stderr=r.stderr))
(scratch/'trace-mutation.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
assert [r['rc'] for r in rows]==[0,1,0]
