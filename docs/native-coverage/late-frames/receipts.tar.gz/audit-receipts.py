from pathlib import Path
from fractions import Fraction
import json, gzip, hashlib, subprocess, tarfile, collections, bisect
root=Path('/private/tmp/wam-late-scratch'); repo=Path('/private/tmp/wam-late'); dest=repo/'docs/native-coverage/late-frames';dest.mkdir(exist_ok=True)
ledger=[];trials=[]
for p in sorted(root.rglob('metrics.jsonl')):
 run=p.parent; launch=run/'launch.json'
 if not launch.exists():continue
 identity=json.loads(launch.read_text());result=json.loads((run/'result.json').read_text()) if (run/'result.json').exists() else {}
 trial=run.parent; own={json.loads(x.read_text())['pid'] for x in trial.glob('*/launch.json')}
 states=[json.loads(s) for s in (trial/'ps-during.jsonl').read_text().splitlines()] if (trial/'ps-during.jsonl').exists() else []
 overlap=[s for s in states if any(int(x.split()[0]) not in own for x in s['processes'])]
 rows=[json.loads(s) for s in p.read_text().splitlines()];traces=[r for r in rows if r.get('record')=='video_frame_trace'];late=[r for r in traces if r['late']];samples=[r for r in rows if r.get('record')=='playback_sample'];last=samples[-1] if samples else {};relative=str(run.relative_to(root));busy=relative.startswith('soaks-corrected/2/')
 health=max((r['lost_or_unavailable'] for r in rows if r.get('record')=='video_trace_health'),default=None)
 trials.append(dict(run=relative,identity=identity,rc=result.get('rc'),native=result.get('native'),gui_quiet=not overlap,host_load_observed=busy,last_sample=last,late_records=len(late),trace_loss=health,complete_accounting=result.get('complete_accounting'),usage=result.get('usage')))
 for r in late:
  hz=r['ticks_per_second'];d=r['deadline_ticks'];duration=Fraction(r['duration_value'],r['duration_scale']);expired=Fraction(d)+duration*hz if d else None
  previous=next((x for x in reversed(traces) if not x['late'] and x['generation']==r['generation'] and x['ordinal']<r['ordinal']),None)
  mechanism='unresolved worker/decode/output interval'
  if d and r['decode_complete_ticks'] and r['decode_complete_ticks']<d and r['surface_lease_ticks']<d:
   mechanism='decoded and leased before deadline; unresolved worker/output delay'
   if r.get('worker_wait_timed_out') and Fraction(r['worker_wait_end_ticks'])>=expired:
    mechanism='worker starvation: timed deadline wait returned after frame interval expiry'
   elif previous and previous['enqueue_return_ticks'] and Fraction(previous['enqueue_return_ticks'])>=expired:
    mechanism='other: preceding output submission crossed this frame interval end; blocking versus descheduling unresolved'
  host_ns=r['observed_ticks']*1000000000//hz
  nearest=min(states,key=lambda s:abs(s['host_ns']-host_ns)) if states else None
  classification='unattributable: sibling GUI overlap in trial' if overlap else 'unqualified busy-host observation' if busy else mechanism
  ledger.append(dict(run=relative,asset=identity['asset'],candidate=identity['identities']['WAM_NATIVE_BENCHMARK_CANDIDATE_ID'],run_id=identity['identities']['WAM_NATIVE_BENCHMARK_RUN_ID'],frame=r['ordinal'],pts=f"{r['pts_value']}/{r['pts_scale']}",classification=classification,observed_mechanism=mechanism,trace=r,preceding_submission=previous,nearest_ps=nearest,ps_distance_ns=abs(nearest['host_ns']-host_ns) if nearest else None,trial_overlap=overlap[:1],host_load_receipt='ps-load-corrected.json' if busy else None))
assert sum(t['late_records'] for t in trials)==len(ledger)
for name,data in [('attribution-ledger.json',ledger),('trial-summary.json',trials)]:
 raw=(json.dumps(data,indent=2)+'\n').encode();(root/name).write_bytes(raw)
 with gzip.open(dest/(name+'.gz'),'wb') as f:f.write(raw)
counts=collections.Counter(r['classification'] for r in ledger)
print('Late records',len(ledger),'classes',dict(counts))
for t in trials:
 if t['run'].startswith(('replays-final','soaks-corrected/2','resources-final')):print(t['run'],t['last_sample'].get('drawn_frames'),t['last_sample'].get('discarded_late_frames'),t['late_records'],t['trace_loss'])
frozen=[]
paths=['src/media/native_media_source.hpp','src/media/native_playback_contract.hpp','tests/native_audio_converter_test.mm']+[str(p.relative_to(repo)) for p in (repo/'tests').glob('native_audio_session_test*')]
for name in paths:
 current=(repo/name).read_bytes();original=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo);assert current==original
 frozen.append(dict(path=name,unchanged=True,sha256=hashlib.sha256(current).hexdigest()))
(dest/'frozen.json').write_text(json.dumps(frozen,indent=2)+'\n')
for name in ['trace-mutation.json','forward-mutation.json','compile-out.json','ps-load-corrected.json']:
 if (root/name).exists():(dest/name).write_bytes((root/name).read_bytes())
with gzip.open(dest/'mixed-packet-map.json.gz','wb') as f:f.write((root/'mixed-packet-map.json').read_bytes())
