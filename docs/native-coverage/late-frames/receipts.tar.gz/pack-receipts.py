from pathlib import Path
import json,tarfile,hashlib
root=Path('/private/tmp/wam-late-scratch');dest=Path('/private/tmp/wam-late/docs/native-coverage/late-frames'); entries=[]; seen=set()
groups=['mixed-baseline','mixed-repeat','mixed-detailed','mixed-final','soaks-baseline','soaks-quiet','soaks-final','soaks-corrected','replays','replays-final','replays-coherent','resources-final']
paths=[p for group in groups for p in (root/group).rglob('*') if p.is_file()]
paths += [p for pattern in ['*.log','ctest*.txt','*.py','*-mutation.json','compile-out.json','ps-load-corrected.json'] for p in root.glob(pattern)]
with tarfile.open(dest/'receipts.tar.gz','w:gz') as archive:
 for p in sorted(paths):
  name=str(p.relative_to(root))
  if name in seen:continue
  seen.add(name);data=p.read_bytes();entries.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()));archive.add(p,arcname=name)
with tarfile.open(dest/'receipts.tar.gz','r:gz') as archive:
 for row in entries:
  data=archive.extractfile(row['path']).read()
  assert hashlib.sha256(data).hexdigest()==row['sha256']
(dest/'receipt-manifest.json').write_text(json.dumps(entries,indent=2)+'\n')
print(len(entries),'archived files verified;', (dest/'receipts.tar.gz').stat().st_size,'bytes')
